/* Automatically generated from Squeak on #(14 August 2002 10:48:50 pm) */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* Default EXPORT macro that does nothing (see comment in sq.h): */
#define EXPORT(returnType) returnType

/* Do not include the entire sq.h file but just those parts needed. */
/*  The virtual machine proxy definition */
#include "sqVirtualMachine.h"
/* Configuration options */
#include "sqConfig.h"
/* Platform specific definitions */
#include "sqPlatformSpecific.h"

#define true 1
#define false 0
#define null 0  /* using 'null' because nil is predefined in Think C */
#include "DShowVideoDecoderPlugin.h"

/* memory access macros */
#define byteAt(i) (*((unsigned char *) (i)))
#define byteAtput(i, val) (*((unsigned char *) (i)) = val)
#define longAt(i) (*((int *) (i)))
#define longAtput(i, val) (*((int *) (i)) = val)

/*** Variables ***/
struct VirtualMachine* interpreterProxy;
const char *moduleName = "DShowVideoDecoderPlugin 14 August 2002 (e)";
double sampleTime;
int sema;

/*** Function Prototypes ***/
#pragma export on
EXPORT(const char*) getModuleName(void);
EXPORT(int) initialiseModule(void);
EXPORT(int) primDecoderCopyLastCapturedFrameInto(void);
EXPORT(int) primDecoderGetDecodeSize(void);
EXPORT(int) primDecoderGetLastError(void);
EXPORT(int) primDecoderGetLastSampleTime(void);
EXPORT(int) primDecoderPause(void);
EXPORT(int) primDecoderRequestCapture(void);
EXPORT(int) primDecoderRun(void);
EXPORT(int) primDecoderSetDecodeSize(void);
EXPORT(int) primDecoderSetRenderRect(void);
EXPORT(int) primDecoderShowWindow(void);
EXPORT(int) primDecoderStop(void);
EXPORT(int) primInitializeDecoder(void);
EXPORT(int) primSetFrameSemaphore(void);
EXPORT(int) primShutdownDecoder(void);
EXPORT(int) setInterpreter(struct VirtualMachine* anInterpreter);
EXPORT(int) shutdownModule(void);
EXPORT(void) signalFrame(double currentSampleTime);
#pragma export off


/*	Note: This is hardcoded so it can be run from Squeak.
	The module name is used for validating a module *after*
	it is loaded to check if it does really contain the module
	we're thinking it contains. This is important! */

EXPORT(const char*) getModuleName(void) {
	return moduleName;
}

EXPORT(int) initialiseModule(void) {
	sema = 0;
	sampleTime = 0.0;
	return 1;
}

EXPORT(int) primDecoderCopyLastCapturedFrameInto(void) {
	int height;
	int bits;
	int width;
	int depth;
	int ret;
	int aForm;
	int _return_value;

	aForm = interpreterProxy->stackValue(0);
	if (interpreterProxy->failed()) {
		return null;
	}
	bits = interpreterProxy->fetchPointerofObject(0, aForm);
	width = interpreterProxy->fetchIntegerofObject(1, aForm);
	height = interpreterProxy->fetchIntegerofObject(2, aForm);
	depth = interpreterProxy->fetchIntegerofObject(3, aForm);
	if (depth < 16) {
		interpreterProxy->primitiveFail();
		return null;
	}
	ret = convertToSqueakForm((unsigned char *)bits+4, width, height, depth);
	if (!(ret)) {
		interpreterProxy->primitiveFail();
		return null;
	}
	_return_value = interpreterProxy->integerObjectOf(ret);
	if (interpreterProxy->failed()) {
		return null;
	}
	interpreterProxy->popthenPush(2, _return_value);
	return null;
}

EXPORT(int) primDecoderGetDecodeSize(void) {
	int result;


	/* result ifFalse: [interpreterProxy success: false. ^ nil]. */

	result = DecoderDecodeSize();
	interpreterProxy->pop(1);
	interpreterProxy->push(interpreterProxy->positive32BitIntegerFor(result));
	if (interpreterProxy->failed()) {
		return null;
	}
	return null;
}

EXPORT(int) primDecoderGetLastError(void) {
	int ret;
	int _return_value;

	ret = DecoderGetLastError();
	_return_value = interpreterProxy->integerObjectOf(ret);
	if (interpreterProxy->failed()) {
		return null;
	}
	interpreterProxy->popthenPush(1, _return_value);
	return null;
}

EXPORT(int) primDecoderGetLastSampleTime(void) {
	int _return_value;

	_return_value = interpreterProxy->floatObjectOf(sampleTime);
	if (interpreterProxy->failed()) {
		return null;
	}
	interpreterProxy->popthenPush(1, _return_value);
	return null;
}

EXPORT(int) primDecoderPause(void) {
	int ret;
	int _return_value;

	ret = DecoderPause();
	if (!(ret)) {
		interpreterProxy->primitiveFail();
		return null;
	}
	_return_value = interpreterProxy->integerObjectOf(ret);
	if (interpreterProxy->failed()) {
		return null;
	}
	interpreterProxy->popthenPush(1, _return_value);
	return null;
}

EXPORT(int) primDecoderRequestCapture(void) {
	int ret;
	int _return_value;

	ret = DecoderCaptureFrame();
	if (!(ret)) {
		interpreterProxy->primitiveFail();
		return null;
	}
	_return_value = interpreterProxy->integerObjectOf(ret);
	if (interpreterProxy->failed()) {
		return null;
	}
	interpreterProxy->popthenPush(1, _return_value);
	return null;
}

EXPORT(int) primDecoderRun(void) {
	int ret;
	int _return_value;

	ret = DecoderRun();
	if (!(ret)) {
		interpreterProxy->primitiveFail();
		return null;
	}
	_return_value = interpreterProxy->integerObjectOf(ret);
	if (interpreterProxy->failed()) {
		return null;
	}
	interpreterProxy->popthenPush(1, _return_value);
	return null;
}

EXPORT(int) primDecoderSetDecodeSize(void) {
	int ret;
	int w;
	int h;
	int _return_value;

	w = interpreterProxy->stackIntegerValue(1);
	h = interpreterProxy->stackIntegerValue(0);
	if (interpreterProxy->failed()) {
		return null;
	}
	ret = DecoderSetDecodeSize(w, h);
	if (!(ret)) {
		interpreterProxy->primitiveFail();
		return null;
	}
	_return_value = interpreterProxy->integerObjectOf(ret);
	if (interpreterProxy->failed()) {
		return null;
	}
	interpreterProxy->popthenPush(3, _return_value);
	return null;
}

EXPORT(int) primDecoderSetRenderRect(void) {
	int ret;
	int x;
	int y;
	int w;
	int h;
	int _return_value;

	x = interpreterProxy->stackIntegerValue(3);
	y = interpreterProxy->stackIntegerValue(2);
	w = interpreterProxy->stackIntegerValue(1);
	h = interpreterProxy->stackIntegerValue(0);
	if (interpreterProxy->failed()) {
		return null;
	}
	ret = SetRenderRect(x, y, w, h);
	if (!(ret)) {
		interpreterProxy->primitiveFail();
		return null;
	}
	_return_value = interpreterProxy->integerObjectOf(ret);
	if (interpreterProxy->failed()) {
		return null;
	}
	interpreterProxy->popthenPush(5, _return_value);
	return null;
}

EXPORT(int) primDecoderShowWindow(void) {
	int ret;
	int showFlag;
	int _return_value;

	showFlag = interpreterProxy->booleanValueOf(interpreterProxy->stackValue(0));
	if (interpreterProxy->failed()) {
		return null;
	}
	ret = ShowRenderWindow(showFlag);
	if (!(ret)) {
		interpreterProxy->primitiveFail();
		return null;
	}
	_return_value = interpreterProxy->integerObjectOf(ret);
	if (interpreterProxy->failed()) {
		return null;
	}
	interpreterProxy->popthenPush(2, _return_value);
	return null;
}

EXPORT(int) primDecoderStop(void) {
	int ret;
	int _return_value;

	ret = DecoderStop();
	if (!(ret)) {
		interpreterProxy->primitiveFail();
		return null;
	}
	_return_value = interpreterProxy->integerObjectOf(ret);
	if (interpreterProxy->failed()) {
		return null;
	}
	interpreterProxy->popthenPush(1, _return_value);
	return null;
}

EXPORT(int) primInitializeDecoder(void) {
	int ret;
	void *theSTWindow;
	int _return_value;

	theSTWindow = (void*) interpreterProxy->ioLoadFunctionFrom("stWindow","");
	if (theSTWindow == null) {
		interpreterProxy->primitiveFail();
		return null;
	}
	ret = SetRenderWindow(theSTWindow);
	if (!(ret)) {
		interpreterProxy->primitiveFail();
		return null;
	}
	ret = InitializeDecoder();
	if (!(ret)) {
		interpreterProxy->primitiveFail();
		return null;
	}
	_return_value = interpreterProxy->integerObjectOf(ret);
	if (interpreterProxy->failed()) {
		return null;
	}
	interpreterProxy->popthenPush(1, _return_value);
	return null;
}

EXPORT(int) primSetFrameSemaphore(void) {
	int ret;
	int semaIndex;
	int _return_value;

	semaIndex = interpreterProxy->stackIntegerValue(0);
	if (interpreterProxy->failed()) {
		return null;
	}
	sema = semaIndex;
	ret = SetCallBackFunction(signalFrame);
	if (!(ret)) {
		interpreterProxy->primitiveFail();
		return null;
	}
	_return_value = interpreterProxy->integerObjectOf(ret);
	if (interpreterProxy->failed()) {
		return null;
	}
	interpreterProxy->popthenPush(2, _return_value);
	return null;
}

EXPORT(int) primShutdownDecoder(void) {
	int ret;
	int _return_value;


	/* 	ret ifFalse: [
		interpreterProxy primitiveFail.
		^ nil
	].
 */

	ret = dshowShutdown();
	_return_value = interpreterProxy->integerObjectOf(ret);
	if (interpreterProxy->failed()) {
		return null;
	}
	interpreterProxy->popthenPush(1, _return_value);
	return null;
}


/*	Note: This is coded so that is can be run from Squeak. */

EXPORT(int) setInterpreter(struct VirtualMachine* anInterpreter) {
	int ok;

	interpreterProxy = anInterpreter;
	ok = interpreterProxy->majorVersion() == VM_PROXY_MAJOR;
	if (ok == 0) {
		return 0;
	}
	ok = interpreterProxy->minorVersion() >= VM_PROXY_MINOR;
	return ok;
}

EXPORT(int) shutdownModule(void) {
	return dshowShutdown();
}

EXPORT(void) signalFrame(double currentSampleTime) {
	sampleTime = currentSampleTime;
	if (sema > 0) {
		interpreterProxy->signalSemaphoreWithIndex(sema);
	}
}
