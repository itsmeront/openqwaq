'c:/Program Files/Microsoft Visual Studio .NET/Vc7/bin/lib' `pwd`/${1}/SampleGrabber.obj
