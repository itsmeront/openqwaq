//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//
// Qwaq Firefox Extension
// Reports URL changes.
// By: Josh Gargus, v0.5
//
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

jslib.init(this);
include (jslib_io);
var DU = new DirUtils;

const listener = {
    onStateChange:function(aProgress,aRequest,aFlag,aStatus) {},
    onProgressChange:function(a,b,c,d,e,f) {},
    onStatusChange:function(a,b,c,d) {},
    onSecurityChange:function(a,b,c) {},
    onLocationChange:function(aProgress,aRequest,aLocation) {

	try{
	    var mh = DU.getMozUserHomeDir();
	    var screen_num = mh.substring(mh.lastIndexOf("-")+1, mh.length);

	    var i = 0;
	    var input = DU.getHomeDir();

	    // This is simplified now that we're using a chroot
	    // environment... we can just use /tmp !	
            var newFile = new File('/tmp/current-url-' + screen_num + '.dat');
	    newFile.create();
	    newFile.open('w');
	    newFile.write(aLocation.spec);
	    newFile.close();
	}
	catch(e){
//	    alert("WTF???");
	}
    }
}

// Initialization
window.addEventListener("load", 
			function(evt) { setTimeout(QwaqExtension_Load, 0, evt); }, 
			false);
window.addEventListener("unload", QwaqExtension_Unload, false);

function QwaqExtension_Load() {
    window.getBrowser()
	  .addProgressListener(listener, Components.interfaces.nsIWebProgress.NOTIFY_LOCATION);
}

function QwaqExtension_Unload() {
    window.getBrowser().removeProgressListener(listener);
}



