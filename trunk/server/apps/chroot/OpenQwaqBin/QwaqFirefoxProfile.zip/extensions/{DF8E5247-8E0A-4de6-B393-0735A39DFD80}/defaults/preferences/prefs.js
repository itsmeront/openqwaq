// pref("toolkit.defaultChromeURI", "chrome://jslib/content/jslib/content/aboutDialog.xul");
